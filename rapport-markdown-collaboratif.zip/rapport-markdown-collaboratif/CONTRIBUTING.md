# Guide de contribution

Merci de contribuer à ce projet !

## Étapes à suivre

1. Crée une branche pour ta section :
   ```bash
   git checkout -b nom-de-ta-branche
   ```
2. Modifie `rapport.md` (ou ajoute une image dans `/images`)
3. Sauvegarde, puis :
   ```bash
   git add .
   git commit -m "Ajout de la section X"
   git push origin nom-de-ta-branche
   ```
4. Va sur GitHub et crée une Pull Request

✅ Un relecteur vérifiera avant de fusionner
