# Rapport Markdown Collaboratif

Ce projet a pour but d’écrire un document scientifique ou pédagogique à plusieurs mains, en utilisant **Markdown**, **Git** et **GitHub**.

## Objectifs

- Écrire ensemble sans écraser les contributions des autres
- Apprendre à utiliser branches, commits, pull requests
- Exporter en PDF, DOCX ou HTML avec pandoc
